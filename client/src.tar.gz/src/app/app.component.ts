import { Component } from '@angular/core';
import { moviesearchservice } from  './app.servicesSearch';
import { favoriteMovieservice } from './app.servicesFavorite';




@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ moviesearchservice, favoriteMovieservice ]
})



export class AppComponent {
  searchText:string;
  movieNameResult = [];
  genreResult;
  totalPages;
  show = false;
  num = 1;


  // For adding favorite to favorite page
  OnFavorite(){

  }


  showFavorite(){
    alert("");
  }




  // For infinte scrolling
  onScroll () {
    this.num ++;
    console.log(this.num);
    this.show = true;
    this.OnSearch();
  }

  // Intialize constructor
  constructor(private moviesearchservice:moviesearchservice){
    this.moviesearchservice
      .getGenre()
      .subscribe(movieNameResult => {
        this.genreResult = movieNameResult.genres;
      });
  }

  // Search from the app.Search Services
  OnSearch(){
    setTimeout(function() {
    }, 10000);
    this.show = true;
    this.moviesearchservice
      .getMovie(this.searchText,this.num)
      .subscribe(movieNameResult => {
        for(let d of movieNameResult.results){ this.movieNameResult.push(d)};
        this.totalPages = movieNameResult.total_pages;
      });
  }


  // Search from genre Api
  onGenre(allGenre) {
    let arr = [];
    for (let genre of allGenre){
      for (let i= 0; i < this.genreResult.length; i++){
        if ( this.genreResult[i].id == genre ){
          arr.push(this.genreResult[i].name);
        }
      }
    }
    return arr;
  }
}
