import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<h2 class="text-center">Page Not Found</h2><router-outlet></router-outlet>',
})

export class NotFound  {

}
